# MEDISEVA 360 — Integration & Completion Guide

This archive preserves the existing frontend and adds/keeps the Node.js + Express + MongoDB API scaffold in `backend/`.

## Existing backend API scaffold
- Authentication: patient signup/login, current user
- Hospital and doctor listing/management APIs
- Appointment booking, cancellation and check-in
- MediQueue queue lookup
- Patient health-record APIs

## Important: not yet production complete
This project has NOT been end-to-end tested with a live MongoDB instance or connected fully to every frontend screen. Configure `backend/.env` from `.env.example`, run the backend, then connect the frontend API calls and test each workflow.

## Remaining integrations (credentials/provider setup required)
1. Payments/refunds: choose an Indian payment provider (e.g. Razorpay) and configure server-side keys/webhooks. Do not collect or store card data directly.
2. SMS/WhatsApp/email: choose a provider, verify sender/template, and configure credentials.
3. Telemedicine: integrate a compliant video provider and consent workflow.
4. ABHA/ABDM and insurance: requires authorized onboarding, credentials, and compliance; no fake connection is included.
5. Live bed/ambulance/pharmacy/hospital availability: connect verified official/provider APIs; records must show source and last-updated time.
6. Multilingual UI: audit every screen for English/Telugu/Hindi translations.
7. Security before real patient data: audit authorization and tenant isolation, validation, rate limits, audit logs, backups, consent, privacy, and applicable Indian requirements.

## Run locally
- Install Node.js 18 or newer.
- In `backend/`: `npm install`, copy `.env.example` to `.env`, set `MONGODB_URI`, a strong `JWT_SECRET`, and `CLIENT_ORIGIN`, then `npm run dev`.
- In the frontend directory: `npm install` and `npm run dev`.
- Test `http://localhost:5000/api/health`; `database: connected` should appear after MongoDB connects.

No real payment, SMS, ABHA/ABDM, live hospital feed, or deployment is claimed until configured and tested. Do not upload secrets or Android signing keys to public GitHub.
