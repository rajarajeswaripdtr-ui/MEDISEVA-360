# MEDISEVA 360 Backend API

Node.js 18+ / Express / MongoDB backend scaffold. It is separate from the React/Vite frontend.

## Run locally
1. Install Node.js 18+ and MongoDB (local MongoDB or a MongoDB Atlas database).
2. Open a terminal in `backend/` and run `npm install`.
3. Copy `.env.example` to `.env` and set a long random `JWT_SECRET`, `MONGODB_URI`, and `CLIENT_ORIGIN`.
4. Run `npm run dev` (or `npm start`). API: `http://localhost:5000`; health check: `/api/health`.

## API routes
- `POST /api/auth/signup`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET /api/hospitals`, `GET /api/hospitals/:id`, `POST /api/hospitals` (hospital admin)
- `GET /api/doctors`, `POST /api/doctors` (hospital admin)
- `POST /api/appointments`, `GET /api/appointments/mine`, `PATCH /api/appointments/:id/cancel`, `PATCH /api/appointments/:id/check-in`
- `GET /api/queue/:hospitalId`
- `GET /api/records/mine`, `POST /api/records`

Use `Authorization: Bearer <token>` for protected routes. Public patient signup creates only PATIENT accounts; hospital/receptionist accounts must be provisioned through a trusted admin workflow. The code provides API scaffolding, not a fully audited production healthcare system. Do not store real patient medical data until security, privacy, consent, audit logging, backups, and applicable Indian healthcare/data-protection requirements have been reviewed. Payment, SMS/WhatsApp, ABHA/ABDM, insurance, live bed counts, and live hospital feeds are not integrated by this scaffold.
