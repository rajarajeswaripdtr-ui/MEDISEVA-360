# MEDISEVA 360 / MediQueue

Frontend: `frontend/` (React + Vite). Backend API: `backend/` (Node.js + Express + MongoDB). See `backend/README.md` for setup.
